# Self Prompt: Professional KO II DAW Interface

Adjust the KO II web app into a professional DAW-style control surface for a connected Teenage Engineering EP-133 / KO II over USB-C while preserving all existing protocol, file, and safety behavior.

## Integrity Rules

- Maintain file and functionality integrity of the existing KO II code at all costs.
- Do not remove or weaken existing read/write safety guards in `te-sysex.js`.
- Do not invent write, delete, move, playback, restore, or sample-transfer commands unless they are verified against connected hardware and guarded by explicit runtime privileges.
- Preserve all existing DOM IDs used by `app.js` unless the app code is updated in the same change.
- Keep local sample import, manifest export, WAV download, MIDI diagnostics, tree cache, and protocol log behavior working.
- Keep the app static and browser-native: no build step, no backend, no hidden dependency.

## Interface Goal

Make the first screen feel like a compact DAW hardware editor, not a lab notebook:

- Persistent transport/status strip with MIDI, SysEx, privilege, selected input/output, port count, chunk size, device ID, SKU, and serial.
- Left-side inspector for connection, runtime settings, and gated device operations.
- Central arrangement/library area with samples, scenes, tracks, pads, and device tree.
- Right-side session/protocol area with proposals, log export, diagnostics, and cached device state.
- Dense controls, clear state, restrained visual design, no marketing layout.

## Function Proposals To Surface

- Official EP Sample Tool parity targets: 999 library slots across ten tabs, groups A-D, 12 pads, assignment dots, sample slot/name/length/current-project context, drag/drop, rename, trim in/out, upload/download/delete, and project backup/restore.
- Recursive read-only device browser with configurable scan depth.
- Device tree export for protocol debugging.
- Protocol log export for reproducing hardware sessions.
- Ten-bank local sample browser and pad grid fed by imported metadata.
- Real-time, interactable left-to-right timeline for local sample playback, imported project clips, and browser-observable MIDI input events.
- Raw PCM import/playback with configurable sample rate, channels, and bit depth.
- Automatic read-only project loading after MIDI/SysEx connection, while preserving manual probe buttons for recovery.
- Live performance controls for local preview, MIDI trigger, or both, with channel/base-note/velocity/gate/hold options.
- Pad context menu, keyboard shortcuts, MIDI panic, and MIDI clock controls for performance sessions.
- Matrix-style visual language and session log for high-contrast performance monitoring.
- Live monitor cards for observed state, MIDI input, MIDI output, SysEx/file probe status, held notes, and clock state.
- Local sample versus cached device tree comparison by normalized filename and byte size.
- Project view for scenes, tracks, clips, pads, and sample references from imported metadata.
- Future verified sample backup using read-only file GET after device paths are confirmed.
- Future pad assignment editor after real project metadata format is validated.
- Future write mode with explicit runtime privilege gating and hardware-tested commands only.
- Future compare/restore workflow using hashes or device metadata after transfer protocol is verified.

## Connected KO II USB-C Test Method

1. Verify Windows sees the device:
   - Query PnP entities for `EP-133`, `VID_2367`, `PID_0020`, `MidiEndpoint`, and `MEDIA`.
   - Expected result: EP-133 USB composite, media, and MIDI endpoint entries have `Status OK`.
2. Serve the static app locally.
3. Open the app in a Web MIDI-capable browser such as Chrome or Edge.
4. Click `Connect MIDI`.
5. Confirm plain MIDI registration first, then SysEx privilege request.
6. Confirm KO II input/output are visible and selected.
7. Confirm auto-load starts when SysEx is granted.
8. Use `Diagnose MIDI` and manual probes only if auto-load does not complete.
9. If SysEx is granted, the read-only sequence should cover:
   - `TE echo`
   - `File init`
   - `Root info`
   - `List root`
   - `Recursive scan`
10. Import WAV/AIFF/PCM locally, play a sample, and verify the timeline playhead moves left to right.
11. Export the protocol log and cached tree after any hardware session.
12. Do not execute write-surface actions unless their implementation has been independently verified.

## Implementation Task

Implement the professional DAW interface in the GitHub repo while preserving the current app behavior. Retest syntax, static wiring, browser rendering where allowed, and connected-device visibility. Commit and push only after the app is functional and the worktree contains the intended files.
